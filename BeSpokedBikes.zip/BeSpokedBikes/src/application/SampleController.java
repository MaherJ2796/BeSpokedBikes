package application;

import javafx.fxml.Initializable;

import java.awt.Label;
import java.net.URL;
import java.sql.Array;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ResourceBundle;

import com.mysql.cj.xdevapi.PreparableStatement;

import Entities.Employee;
import Entities.Sales;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import mySQL.prepStatements;


public class SampleController implements Initializable {
	@FXML
    private TextField SaleEmpNm;

    @FXML
    private TextField comissionPercentage;

    @FXML
    private Button confirmSale;

    @FXML
    private TableColumn<Sales, String> custNameDisp;

    @FXML
    private TextField customerAddress;

    @FXML
    private TextField customerFirstName;

    @FXML
    private TextField customerID;

    @FXML
    private TextField customerLastName;

    @FXML
    private TextField customerPhone;

    @FXML
    private TableColumn<Sales, String> dispProdNm;

    @FXML
    private TextField employeeAddress;

    @FXML
    private TextField employeeFirstName;

    @FXML
    private TextField employeeID;

    @FXML
    private TableColumn<Employee, Integer> employeeIDCol;

    @FXML
    private TextField employeeLastName;

    @FXML
    private TableColumn<Employee, String> employeeLastNameCol;

    @FXML
    private TextField employeePhone;

    @FXML
    private TableView<Employee> employeeTable;

    @FXML
    private TextField manufacturer;

    @FXML
    private TextField manufacturer11;

    @FXML
    private Button newEmployeeConf;

    @FXML
    private TextField productID;

    @FXML
    private TextField productID11;

    @FXML
    private ListView<String> productList;

    @FXML
    private TextField productName;

    @FXML
    private TextField productName11;

    @FXML
    private TextField purchasePrice;

    @FXML
    private TextField purchasePrice11;

    @FXML
    private TextField quatity;

    @FXML
    private TextField quatity11;

    @FXML
    private TextField saleCustName;

    @FXML
    private TextField saleId;

    @FXML
    private TableColumn<Sales, Integer> saleIdDisp;
    
    @FXML
    private TableColumn<Sales, Double> dispSalesPrice;

    @FXML
    private TextField salePrice;
    

    @FXML
    private TableView<Sales> salesTable;

    @FXML
    private TextField saleProdNm;

    @FXML
    private TextField salesPrice;

    @FXML
    private Button showProducts;

    @FXML
    private Button showProducts1;

    @FXML
    private Button showProducts11;

    @FXML
    private Button showProducts2;

	    @FXML
	    void addProduct(ActionEvent event) {
	    	int ID = Integer.valueOf(productID.getText());
	    	String name = productName.getText();
	    	String manufact = manufacturer.getText();
	    	Double pp = Double.valueOf(purchasePrice.getText());
	    	Double sp = Double.valueOf(salesPrice.getText());
	    	int quant = Integer.valueOf(quatity.getText());
	    	Double commisPerc = Double.valueOf(comissionPercentage.getText());
	    	
	    	prepStatements.addProducts(ID, name, manufact, pp, sp, quant, commisPerc);
	    	

	    }
	    
	    @FXML
	    void viewProducts(ActionEvent event) {
	    	ObservableList<String> result =FXCollections.observableArrayList(prepStatements.getProducts());
	    	productList.setItems(result);
	    	 
	    	
	    }
	   
	    
	    @FXML
	    void viewEmployeeId(ActionEvent event) {
	    	
	    	
	    	ResultSet rs = prepStatements.getEmployeeInfo();
	    	try {
				while(rs.next()) {
				employeeIDCol.setCellValueFactory(new PropertyValueFactory<Employee,Integer>("employeeID"));
				employeeLastNameCol.setCellValueFactory(new PropertyValueFactory<Employee,String>("employeeLastName"));
				employeeTable.getItems().add(new Employee(rs.getInt(1),rs.getString(2)));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	 
	    	
	    }
	    
	    @FXML
	    void viewSales(ActionEvent event) {
	    	
	    	
	    	ResultSet rs = prepStatements.getSalesInfo();
	    	try {
				while(rs.next()) {
				custNameDisp.setCellValueFactory(new PropertyValueFactory<Sales,String>("customerName"));
				dispProdNm.setCellValueFactory(new PropertyValueFactory<Sales,String>("productName"));
				dispSalesPrice.setCellValueFactory(new PropertyValueFactory<Sales,Double>("price"));
				salesTable.getItems().add(new Sales(rs.getString(1),rs.getDouble(3)));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	 
	    	
	    }
	    @FXML
	    void addEmployee(ActionEvent event) {
	    	int ID = Integer.valueOf(employeeID.getText());
	    	String fname = employeeFirstName.getText();
	    	String lname = employeeLastName.getText();
	    	String address = employeeAddress.getText();
	    	String phone = employeePhone.getText();
	    	
	    	prepStatements.addEmployee(ID, fname, lname, address, phone);
	    	

	    }
	    @FXML
	    void addCustomer(ActionEvent event) {
	    	int ID = Integer.valueOf(customerID.getText());
	    	String fname = customerFirstName.getText();
	    	String lname = customerLastName.getText();
	    	String address = customerAddress.getText();
	    	String phone = customerPhone.getText();
	    	
	    	prepStatements.addCustomer(ID, fname, lname, address, phone);
	    	

	    }
	    @FXML
	    void addSale(ActionEvent event) {
	    	int saleID = Integer.valueOf(saleId.getText());
	    	String productNm = saleProdNm.getText();
	    	String custNm = saleCustName.getText();
	    	String empNm = SaleEmpNm.getText();
	    	double price = Double.valueOf(salePrice.getText());
	    	
	    	
	    	
	    	prepStatements.addSale(saleID, custNm, empNm, price, productNm);
	    	

	    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	
}
