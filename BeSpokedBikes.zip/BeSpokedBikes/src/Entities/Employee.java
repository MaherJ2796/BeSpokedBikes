package Entities;

public class Employee {
	int employeeID;
	String employeeLastName;
	
	public Employee(int employeeId, String employeeLastName){
		this.employeeID = employeeId;
		this.employeeLastName = employeeLastName;
	}
	
	public int getEmployeeID() {
		return employeeID;
	}
	
	public String getEmployeeLastName() {
		return employeeLastName;
	}
	
	

}
