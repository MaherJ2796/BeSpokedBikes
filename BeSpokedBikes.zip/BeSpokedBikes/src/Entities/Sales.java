package Entities;

public class Sales {
	
	String productName;
	String saleCustomerName;
	double price;
	
	public Sales(String productName,double price) {
		
		this.productName = productName;
		//this.saleCustomerName = saleCustomerName;
		this.price = price;
		
	}
	
	public String getProductName() {
		return productName;
	}
	public String getCustName() {
		return saleCustomerName;
	}
	
	public double price() {
		return price;
	}

}
