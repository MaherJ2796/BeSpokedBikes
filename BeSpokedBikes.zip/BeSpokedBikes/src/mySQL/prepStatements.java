package mySQL;
import java.sql.*;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class prepStatements {
	
	
	public static ArrayList<String> getProducts() {
		
		ArrayList<String> result = new ArrayList<String>();
		
		
		try {
			String myUrl = "jdbc:mysql://localhost:3306/?user=root";
		      String password = "RiseUp22!"; 
		      Connection conn = DriverManager.getConnection(myUrl, "root", password);
		      String sql = "select productName "
				+ "from BeSpokedBikes.Products;";
				PreparedStatement ps = conn.prepareStatement(sql);
				 ResultSet rs = ps.executeQuery();
				 
				 while(rs.next()) {
					 result.add(rs.getString(1));
					 
					
				 }
				
			}

		catch(Exception exc) {
				exc.printStackTrace();
			}
			return result;
		}
	
	public static ResultSet getEmployeeInfo() {
		
		ResultSet rs = null;
		
		
		try {
			String myUrl = "jdbc:mysql://localhost:3306/?user=root";
		      String password = "RiseUp22!"; 
		      Connection conn = DriverManager.getConnection(myUrl, "root", password);
		      String sql = "select idEmployees,lastName from BeSpokedBikes.Employees;";
				
				PreparedStatement ps = conn.prepareStatement(sql);
				  rs = ps.executeQuery();
				 
				
				
			}

		catch(Exception exc) {
				exc.printStackTrace();
			}
			return rs;
		}
	
	
	
public static ResultSet getSalesInfo() {
		
		ResultSet rs = null;
		
		
		try {
			String myUrl = "jdbc:mysql://localhost:3306/?user=root";
		      String password = "RiseUp22!"; 
		      Connection conn = DriverManager.getConnection(myUrl, "root", password);
		      String sql = "select productName,customerName,salePrice from BeSpokedBikes.Sales;";
				
				PreparedStatement ps = conn.prepareStatement(sql);
				  rs = ps.executeQuery();
				 
				
				
			}

		catch(Exception exc) {
				exc.printStackTrace();
			}
			return rs;
		}
public static void addProducts(int productID, String productName, String manufacturer, Double purchasePrice, Double salesPrice, int quantity, Double comissionPercentage) {
		
		try {
		      String myUrl = "jdbc:mysql://localhost:3306/?user=root";
		      String password = "RiseUp22!";
		      
		      Connection conn = DriverManager.getConnection(myUrl, "root", password);
			
			String sql = " insert into BeSpokedBikes.Products(idProducts,productName, manufacturer, purchasePrice, salesPrice, quatity, comissionPercentage)\n"
					+ "values (?,?,?,?,?,?,?);";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, productID);
			ps.setString(2, productName);
			ps.setString(3, manufacturer);
			ps.setDouble(4, purchasePrice);
			ps.setDouble(5, salesPrice);
			ps.setInt(6, quantity);
			ps.setDouble(7, comissionPercentage);
			
			
			ps.execute();
			conn.close();

			}

		catch(Exception exc) {
				exc.printStackTrace();
			}
		}

public static void addEmployee(int employeeID, String firstName, String lastName, String address, String phone) {
	
	try {
	      String myUrl = "jdbc:mysql://localhost:3306/?user=root";
	      String password = "RiseUp22!";
	      
	      Connection conn = DriverManager.getConnection(myUrl, "root", password);
		
		String sql = " insert into BeSpokedBikes.Employees(idEmployees,firstName, lastName, address, phone)\n"
				+ "values (?,?,?,?,?);";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, employeeID);
		ps.setString(2, firstName);
		ps.setString(3, lastName);
		ps.setString(4, address);
		ps.setString(5, phone);
		
		
		
		ps.execute();
		conn.close();

		}

	catch(Exception exc) {
			exc.printStackTrace();
		}
	}

public static void addCustomer(int customerID, String firstName, String lastName, String address, String phone) {
	
	try {
	      String myUrl = "jdbc:mysql://localhost:3306/?user=root";
	      String password = "RiseUp22!";
	      
	      Connection conn = DriverManager.getConnection(myUrl, "root", password);
		
		String sql = " insert into BeSpokedBikes.Customers(idCustomers,firstName, lastName, address, phone)\n"
				+ "values (?,?,?,?,?);";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1,customerID);
		ps.setString(2, firstName);
		ps.setString(3, lastName);
		ps.setString(4, address);
		ps.setString(5, phone);
		
		
		
		ps.execute();
		conn.close();

		}

	catch(Exception exc) {
			exc.printStackTrace();
		}
	}
public static void addSale(int saleID, String custName , String empName , double salePrice, String prodName) {
	
	try {
	      String myUrl = "jdbc:mysql://localhost:3306/?user=root";
	      String password = "RiseUp22!";
	      
	      Connection conn = DriverManager.getConnection(myUrl, "root", password);
		
		String sql = " insert into BeSpokedBikes.Sales(idSales,customerName, employeeLastName, salePrice,productName )\n"
				+ "values (?,?,?,?,?);";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, saleID);
		ps.setString(2, custName);
		ps.setString(3, empName);
		ps.setDouble(4, salePrice);
		ps.setString(5, prodName);

	
		
		
		ps.execute();
		conn.close();

		}

	catch(Exception exc) {
			exc.printStackTrace();
		}
	}


	
	

	

}
